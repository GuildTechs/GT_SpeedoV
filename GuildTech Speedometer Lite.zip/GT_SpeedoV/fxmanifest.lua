fx_version 'cerulean'
game 'gta5'
lua54 'yes'

author 'GuildTech'
version '1.0.0'

shared_script 'config.lua'

client_scripts {
    'client/main.lua'
}

server_scripts {
    'server/main.lua'
}

files {
    'html/index.html',
    'html/style.css',
    'html/script.js'
}

ui_page 'html/index.html'

escrow_ignore {
    'config.lua',
    'html/index.html',
    'html/style.css',
    'html/script.js'
}