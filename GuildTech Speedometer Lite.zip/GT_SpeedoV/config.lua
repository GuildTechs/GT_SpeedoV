Config = {}

Config.Framework = 'qb-core' -- qb-core / qbx_core / es_extended

Config.FuelSystem = 'legacyfuel' -- legacyfuel / cdn_fuel / fr_fuel / ox_fuel

Config.DefaultSpeedUnit = 'kmh' -- 'kmh' or 'mph'

Config.DefaultFuelUnit = 'liters' -- 'liters' or 'gallons'
