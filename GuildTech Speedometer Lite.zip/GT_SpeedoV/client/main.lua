local shown = false

local function getFuelPercentage(veh)
    local fuelTankCapacity = GetVehicleHandlingFloat(veh, 'CHandlingData', 'fPetrolTankVolume')
    local currentFuel = GetVehicleFuelLevel(veh)
    fuelTankCapacity = fuelTankCapacity > 0 and fuelTankCapacity or 100.0
    return math.floor((currentFuel / fuelTankCapacity) * 10000) / 100
end

local function getStreetName()
    local ped = PlayerPedId()
    local coords = GetEntityCoords(ped)
    local streetHash, crossingHash = GetStreetNameAtCoord(coords.x, coords.y, coords.z)
    local street = GetStreetNameFromHashKey(streetHash)
    local crossing = GetStreetNameFromHashKey(crossingHash)

    if crossing and crossing ~= "" then
        return street .. " & " .. crossing
    else
        return street
    end
end

CreateThread(function()
    local wasInVehicle = false
    while true do
        Wait(100)
        local ped = PlayerPedId()
        local inVeh = IsPedInAnyVehicle(ped, false)

        if inVeh and not wasInVehicle then
            SendNUIMessage({ action = "show" })
            wasInVehicle = true
        elseif not inVeh and wasInVehicle then
            SendNUIMessage({ action = "hide" })
            wasInVehicle = false
        end

        if inVeh then
            local veh = GetVehiclePedIsIn(ped, false)
            local speed = GetEntitySpeed(veh) * 2.23694 -- MPH
            local fuelPercent = getFuelPercentage(veh)
            local street = getStreetName()

            SendNUIMessage({
                action = "update",
                speed = math.floor(speed),
                fuel = fuelPercent,
                speedUnit = "mph",
                fuelUnit = "gallons",
                street = street
            })
        end
    end
end)
