Locales = {
    ['en'] = {
        speed_unit = 'Speed Unit',
        fuel_unit = 'Fuel Unit',
        speed_unit_desc = 'Choose between KM/H or MPH',
        fuel_unit_desc = 'Choose Liters or Gallons',
    }
}
