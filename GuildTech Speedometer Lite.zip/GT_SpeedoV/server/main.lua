RegisterNetEvent("GT_SpeedoV:Debug")
AddEventHandler("GT_SpeedoV:Debug", function(msg)
    print("^3[GT_SpeedoV]^0: " .. msg)
end)
