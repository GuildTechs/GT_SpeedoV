const tickContainer = document.querySelector(".ticks");
tickContainer.innerHTML = '';

const maxSpeed = 140;
const sweepAngle = 270;
const radiusOffset = -145;

// Generate speed ticks
for (let i = 0; i <= maxSpeed; i += 10) {
    const angle = (i / maxSpeed) * sweepAngle - (sweepAngle / 2);
    const tick = document.createElement("span");

    tick.textContent = i.toString();
    tick.style.position = 'absolute';
    tick.style.transformOrigin = 'center center';
    tick.style.fontSize = '13px';
    tick.style.color = 'white';
    tick.style.width = '30px';
    tick.style.textAlign = 'center';
    tick.style.transform = `rotate(${angle}deg) translate(0px, ${radiusOffset}px) rotate(${-angle}deg)`;

    tickContainer.appendChild(tick);
}

window.addEventListener("message", function (event) {
    const data = event.data;

    if (data.action === "show") {
        document.getElementById("speedo").style.display = "flex";
    } else if (data.action === "hide") {
        document.getElementById("speedo").style.display = "none";
    } else if (data.action === "update") {
        // Needle rotation
        const angle = (Math.min(data.speed, maxSpeed) / maxSpeed) * sweepAngle - (sweepAngle / 2);
        document.getElementById("needle").style.transform = `rotate(${angle}deg)`;

        // Speed display
        document.getElementById("speedValue").textContent = data.speed;
        document.getElementById("speedUnit").textContent = data.speedUnit?.toUpperCase() || "MPH";

        // Fuel arc update
        const fuelPath = document.getElementById("fuelPath");
        if (fuelPath && data.fuel !== undefined) {
            const fuelPercent = Math.max(0, Math.min(data.fuel, 100));
            const dashOffset = 314 * ((100 - fuelPercent) / 100);
            fuelPath.style.strokeDashoffset = dashOffset;

            if (fuelPercent > 25) {
                fuelPath.style.stroke = 'lime';
            } else if (fuelPercent > 10) {
                fuelPath.style.stroke = 'orange';
            } else {
                fuelPath.style.stroke = 'red';
            }
        }

        // Street name display
        if (data.street !== undefined) {
            const street = document.getElementById("streetName");
            if (street) {
                street.textContent = data.street;
            }
        }
    }
});
